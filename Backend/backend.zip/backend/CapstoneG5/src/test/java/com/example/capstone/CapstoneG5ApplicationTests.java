package com.example.capstone;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CapstoneG5ApplicationTests {

	@Test
	void contextLoads() {
	}

}
